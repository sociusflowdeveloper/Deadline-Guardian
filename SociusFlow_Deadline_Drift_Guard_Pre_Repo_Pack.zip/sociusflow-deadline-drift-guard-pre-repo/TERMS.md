# TERMS.md — Proposed User Terms

**DRAFT FOR LEGAL AND MANAGEMENT REVIEW — NOT IN FORCE, NOT PUBLISHED**  
**Proposed operator/publisher:** SociusFlow Pte. Ltd. | **Product:** Academic Deadline Drift Guard  
**Draft date:** 1 November 2026 (SGT) | **Effective date:** NOT SET  
**Governing law:** Singapore, subject to non-excludable rights and applicable mandatory laws elsewhere.

**Important distinction.** For open-source code redistributed under an approved licence, the relevant licence controls the permissions for copying, using and modifying that code. These proposed terms cover any official project site or operator-provided service if launched; they do not silently revoke an open-source licence or bind a person merely for viewing a public GitHub repository. No hosted service exists in the v0.1 architecture.

## 1. Description

Academic Deadline Drift Guard is intended to analyse user-supplied academic deadline information, identify differences or conflicts and propose updates for user review. It does not independently verify institutional authenticity, contact lecturers, guarantee course compliance or automatically change a calendar in the proposed v0.1 scope.

## 2. Eligibility and age

The controlled initial programme is intended for individuals aged 18 or over. It has no user account and no automated age verification. Any future service opened to minors will need an expressly approved age-appropriate design, notices and safety controls. Parents/guardians and institutions remain responsible for supervision or permissions as applicable; do not represent this as a substitute for relevant legal consent analysis.

## 3. Acceptable use and restrictions

Users must have permission to submit the material; respect other people's privacy, academic content ownership and institutional rules; verify consequential deadlines with the issuing institution; avoid uploading access credentials or other students' personal data; and not attempt to exploit, compromise, overload or use a hosted service unlawfully. Do not use the project for unauthorised scraping, credential collection, surveillance, impersonation, malware or harassment.

The project does not write essays, submit coursework, grade students or determine an institution's rules. Users remain responsible for reviewing reports and taking actions. No one may present a proposed or disputed deadline as institution-confirmed solely because the software produced it.

## 4. User input and intellectual property

Users retain rights they hold in their own materials, subject to third-party rights. They must ensure they are entitled to use and provide them to any chosen AI host. The licence for published code (if eventually approved) will be specified in `LICENSE`; the SociusFlow name, logo, registered or unregistered trade marks and third-party school materials are not automatically licensed for branding use.

## 5. External AI platforms

Use within Claude, ChatGPT, Grok or another host is subject to the host's own eligibility, terms, subscriptions, usage rules, privacy and technical controls. SociusFlow does not represent that every provider supports every feature or that host processing is local.

## 6. Accuracy and educational disclaimer

Outputs are informational aids and may contain errors, omissions or inconsistent interpretations. The official course owner or institution remains the authority for its deadlines. Users must check original notices before important decisions. There is no guarantee of uninterrupted availability or fitness for a particular academic, legal or commercial purpose.

## 7. 'As is' and liability (LEGAL REVIEW REQUIRED)

**Proposed wording:** To the extent permitted by applicable law, any official tool or service is provided on an “as is” and “as available” basis without warranties not expressly stated. To the extent lawful and reasonable in the circumstances, the publisher's aggregate contractual liability arising from an official free service would be limited to **S$100** per claimant, with exclusion of indirect or consequential loss where legally permissible. **This figure is a drafting proposal, not an approved or enforceable limit.**

Nothing is intended to exclude or restrict liability that cannot lawfully be excluded, including fraud, and any applicable consumer protections or statutory constraints. A Singapore-qualified lawyer should specifically assess reasonableness, enforceability, applicable consumer law, jurisdiction, cross-border use, and interaction with Apache-2.0 before these terms are adopted. Do not use this clause as a substitute for product accuracy or safety controls.

## 8. Availability, changes, termination

The maintainers may publish new versions, suspend unsafe releases, or retire an official service with notice appropriate to the circumstances. They cannot remotely erase copies of permissively licensed open-source code already distributed. Changes to these terms take effect only after publication with an actual effective date; material changes require internal approval.

## 9. Payments and refund policy

No pricing, subscription, invoicing or in-app payment is authorised for v0.1. Users may incur charges from their chosen AI provider independently. Any paid SociusFlow plan requires a new consumer-contract, cancellation/refund and payment/privacy review before introduction.

## 10. Contact and disputes

A verified official support/privacy contact and company address or registered-office disclosures, as required for the chosen service context, must be added before publication. No contact route is presumed functional from this draft. Seek good-faith resolution first; mandatory statutory rights remain unaffected. Proposed forum for applicable disputes: courts of Singapore, subject to mandatory consumer/jurisdictional rules.

## Release checklist for counsel

- [ ] Confirm correct legal entity, contact address and authorised signatory.
- [ ] Confirm intended user age rules, market jurisdictions and whether terms bind a hosted service at all.
- [ ] Confirm licensing hierarchy and any open-source copyright notices.
- [ ] Review liability cap, disclaimers, exclusions and mandatory consumer protections.
- [ ] Review actual platform relationships and third-party permissions.
- [ ] Approve notice/acceptance method where contract formation is intended.
- [ ] Confirm claims match tested functionality and `PRIVACY POLICY.md`.

**NOT APPROVED.** No representation is made that this draft currently creates enforceable terms.
